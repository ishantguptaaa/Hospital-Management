/**
 * 
 */
package org.cts.dataaccess;

import org.cts.model.Patient;

/**
 * @author yoges
 *
 */

public interface PatientDAO {
	boolean registerPatient (Patient patientObj);
}
