/**
 * 
 */
package org.cts.dataaccess;

import org.cts.model.Bill;

/**
 * @author yoges
 *
 */
public interface BillDAO {
	
	boolean generateBill (Bill bill);

}
