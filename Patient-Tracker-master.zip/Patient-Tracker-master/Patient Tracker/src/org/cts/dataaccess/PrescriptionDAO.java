/**
 * 
 */
package org.cts.dataaccess;

import org.cts.model.Prescription;
/**
 * @author yoges
 *
 */
public interface PrescriptionDAO {
	
	boolean generatePrescription (Prescription p);
}
