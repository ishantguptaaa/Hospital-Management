/**
 * 
 */
package org.cts.dataaccess;

import org.cts.model.Doctor;

/**
 * @author yoges
 *
 */
public interface DoctorDAO {
	
	boolean registerDoctor (Doctor doctorObj);
}
