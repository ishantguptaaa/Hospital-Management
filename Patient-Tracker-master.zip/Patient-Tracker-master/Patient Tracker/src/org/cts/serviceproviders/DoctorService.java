/**
 * 
 */
package org.cts.serviceproviders;

import org.cts.model.Doctor;

/**
 * @author yoges
 *
 */
public interface DoctorService {
	
	boolean registerDoctorService (Doctor doctor);
}
