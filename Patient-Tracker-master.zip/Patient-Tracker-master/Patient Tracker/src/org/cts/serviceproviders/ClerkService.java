/**
 * 
 */
package org.cts.serviceproviders;

import org.cts.model.Clerk;

/**
 * @author yoges
 *
 */

public interface ClerkService {
	boolean registerClerkService (Clerk clerk);
}
