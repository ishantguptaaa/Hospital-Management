/**
 * 
 */
package org.cts.utilities;

/**
 * @author yoges
 *
 */
public class DBUtilityConstants {
	
	public static final String DRIVER = "com.mysql.cj.jdbc.Driver";
	public static final String URL = "jdbc:mysql://localhost:3306/hospital";
	public static final String USERNAME = "root";
	public static final String PASSWORD = "system";
	
}
